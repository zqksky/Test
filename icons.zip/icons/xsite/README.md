# @amat/icons-xsite

This package contains AMAT font icons for the Xsite Project.

[Preview](http://webui.amat.com/icons/#/icons/xsite) |
[Repository](http://reviews.amat.com/diffusion/WEBICONS/)

## Getting Started

### Step 1: Installation

In order to install this package you must be using our internal npm repository.

If your registry is configured already you can use npm directly as follows:

```sh
npm install --save @amat/icons-xsite
```

If you don't have the registry configured you can use the --registry command line argument:

```sh
npm install @amat/icons-xsite --registry "https://registry.amat.npme.io/"
```

#### Configuration

To see what registry you are using you can use the `npm config get registry` command.

```sh
> npm config get registry
https://registry.amat.npme.io/
```

See npm documentation about how to configure npm if needed: https://docs.npmjs.com/files/npmrc

### Step 2: Import the icon font
If you are using an Angular CLI project, add the following line to your styles.scss:
```javascript
// the Xsite icons - prefix "icon-amat-xsite"
@import '~@amat/icons-xsite/icon-amat-xsite.css';
```
Otherwise, simply import the icon css file in the head section of your index.html.

### Step 3: Use the icons in templates
To use the icons you need to use the `<i>` tag and simply specify the icon class and the icon will appear.
```html
<i class="icon-amat-xsite-work-request"></i>
```
