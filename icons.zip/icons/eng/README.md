# @amat/icons-eng

This package contains AMAT font icons for the EngineeredWorks Project.

[Preview](http://webui.amat.com/icons/#/icons/eng) |
[Repository](http://reviews.amat.com/diffusion/WEBICONS/)

## Getting Started

### Step 1: Installation

In order to install this package you must be using our internal npm repository.

If your registry is configured already you can use npm directly as follows:

```sh
npm install --save @amat/icons-eng
```

If you don't have the registry configured you can use the --registry command line argument:

```sh
npm install @amat/icons-eng --registry "https://registry.amat.npme.io/"
```

#### Configuration

To see what registry you are using you can use the `npm config get registry` command.

```sh
> npm config get registry
https://registry.amat.npme.io/
```

See npm documentation about how to configure npm if needed: https://docs.npmjs.com/files/npmrc

### Step 2: Import the icon font
If you are using an Angular CLI project, add the following line to your styles.scss:
```javascript
// the EngineeredWorks icons - prefix "icon-amat-eng"
@import '~@amat/icons-eng/icon-amat-eng.css';
```
Otherwise, simply import the icon css file in the head section of your index.html.

### Step 3: Use the icons in templates
To use the icons you need to use the `<i>` tag and simply specify the icon class and the icon will appear.
```html
<i class="icon-amat-eng-plan-edits"></i>
```

## Deprecated icons

The following icons are only included for backwards compatibility. Eventually they will be removed from this package since they have been moved into [@amat/icons-core](https://amat.npme.io/package/@amat/icons-core).

| Legacy name | New name
| --- | ---
| icon-amat-eng-closed-book | icon-amat-core-help-closed-book
| icon-amat-eng-collapse-ui | icon-amat-core-help-collapse-ui
| icon-amat-eng-compare | icon-amat-core-compare
| icon-amat-eng-contents | icon-amat-core-help-contents
| icon-amat-eng-create-plan | icon-amat-core-edit-circle
| icon-amat-eng-datagrid | icon-amat-core-datagrid
| icon-amat-eng-download | icon-amat-core-download
| icon-amat-eng-export | icon-amat-core-export
| icon-amat-eng-history | icon-amat-core-history
| icon-amat-eng-import | icon-amat-core-import
| icon-amat-eng-index | icon-amat-core-help-index
| icon-amat-eng-inputs | icon-amat-core-inputs
| icon-amat-eng-model-alert | icon-amat-core-alert-circle-mini
| icon-amat-eng-model-arrow | icon-amat-core-forward-arrow-mini
| icon-amat-eng-model-edit | icon-amat-core-edit-circle-mini
| icon-amat-eng-model-error | icon-amat-core-error-mini
| icon-amat-eng-model-locked | icon-amat-core-locked-mini
| icon-amat-eng-model-minus | icon-amat-core-minus-mini
| icon-amat-eng-outputs | icon-amat-core-outputs
| icon-amat-eng-page | icon-amat-core-help-page
| icon-amat-eng-plan-edits | icon-amat-core-schedule-edit
| icon-amat-eng-process-finish-mini | icon-amat-core-check-mini
| icon-amat-eng-process-run-mini | icon-amat-core-refresh-mini
| icon-amat-eng-remove-highlight | icon-amat-core-help-remove-highlight
| icon-amat-eng-reserve2 | icon-amat-core-reserve-wide
| icon-amat-eng-revise-plan | icon-amat-core-schedule-add
| icon-amat-eng-upload | icon-amat-core-upload

