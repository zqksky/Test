# @amat/icons-300works

This package contains AMAT font icons for the 300 Works Project.

[Preview](http://webui.amat.com/icons/#/icons/300works) |
[Repository](http://reviews.amat.com/diffusion/WEBICONS/)

## Getting Started

### Step 1: Installation

In order to install this package you must be using our internal npm repository.

If your registry is configured already you can use npm directly as follows:

```sh
npm install --save @amat/icons-300works
```

If you don't have the registry configured you can use the --registry command line argument:

```sh
npm install @amat/icons-300works --registry "https://registry.amat.npme.io/"
```

#### Configuration

To see what registry you are using you can use the `npm config get registry` command.

```sh
> npm config get registry
https://registry.amat.npme.io/
```

See npm documentation about how to configure npm if needed: https://docs.npmjs.com/files/npmrc

### Step 2: Import the icon font
If you are using an Angular CLI project, add the following line to your styles.scss:
```javascript
// the 300works icons - prefix "icon-amat-300works"
@import '~@amat/icons-300works/icon-amat-300works.css';
```
Otherwise, simply import the icon css file in the head section of your index.html.

### Step 3: Use the icons in templates
To use the icons you need to use the `<i>` tag and simply specify the icon class and the icon will appear.
```html
<i class="icon-amat-300works-active-works"></i>
```

## Deprecated icons

The following icons are only included for backwards compatibility. Eventually they will be removed from this package since they have been moved into [@amat/icons-core](https://amat.npme.io/package/@amat/icons-core).

| Legacy name | New name
| --- | ---
| icon-amat-300works-users-security | icon-amat-core-user-security
| icon-amat-300works-clock-on | icon-amat-core-clock-on-mini
| icon-amat-300works-clock-off | icon-amat-core-clock-off-mini
| icon-amat-300works-waive-work | icon-amat-core-circle-arrowdot-down-mini
| icon-amat-300works-unwaive-work | icon-amat-core-circle-arrowdot-up-mini
| icon-amat-300works-delay-work | icon-amat-core-circle-arrowdot-back-mini
| icon-amat-300works-undelay-work | icon-amat-core-circle-arrowdot-forward-mini
| icon-amat-300works-activate-work | icon-amat-core-sqaure-power-off-mini
| icon-amat-300works-cancel-work | icon-amat-core-square-cancel-mini
| icon-amat-300works-complete-work | icon-amat-core-square-checkdot-mini
| icon-amat-300works-start-work | icon-amat-core-shield-arrowdot-forward-mini
| icon-amat-300works-steps | icon-amat-core-line-point
| icon-amat-300works-steps-mini | icon-amat-core-line-point-mini
| icon-amat-300works-recent-mini | icon-amat-core-clock-mini
| icon-amat-300works-edc-plans-mini | icon-amat-core-file-chart-mini
| icon-amat-300works-folder | icon-amat-core-folder-mini
| icon-amat-300works-proxy-area | amat-core-box-dot-arrow.svg
| icon-amat-300works-proxy-area-mini | amat-core-box-dot-arrow-mini.svg
| icon-amat-300works-capability-bank | amat-core-check-box.svg
| icon-amat-300works-capability-bank-mini | amat-core-check-box-mini.svg
| icon-amat-300works-process-plans | amat-core-line-point-arrow.svg
| icon-amat-300works-process-plans-mini | amat-core-line-point-arrow-mini.svg
| icon-amat-300works-states-transition | amat-core-state-line-arrow-circle-dot
| icon-amat-300works-states-transition-mini | amat-core-state-line-arrow-circle-dot-mini
