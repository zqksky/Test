# @amat/icons-core

This package contains the core set of AMAT font icons.

[Preview](http://webui.amat.com/icons/#/icons/core) |
[Repository](http://reviews.amat.com/diffusion/WEBICONS/)

## Getting Started

### Step 1: Installation

In order to install this package you must be using our internal npm repository.

If your registry is configured already you can use npm directly as follows:

```sh
npm install --save @amat/icons-core
```

If you don't have the registry configured you can use the --registry command line argument:

```sh
npm install @amat/icons-core --registry "https://registry.amat.npme.io/"
```

#### Configuration

To see what registry you are using you can use the `npm config get registry` command.

```sh
> npm config get registry
https://registry.amat.npme.io/
```

See npm documentation about how to configure npm if needed: https://docs.npmjs.com/files/npmrc

### Step 2: Import the icon font
If you are using an Angular CLI project, add the following line to your styles.scss:
```javascript
// the ui kit icons - prefix "icon-amat-core"
@import '~@amat/icons-core/icon-amat-core.css';
```
Otherwise, simply import the icon css file in the head section of your index.html.

### Step 3: Use the icons in templates
To use the icons you need to use the `<i>` tag and simply specify the icon class and the icon will appear.
```html
<i class="icon-amat-core-warning"></i>
```

## Deprecated icons

The following icons are only included for backwards compatibility just in case they are being used. Eventually they will be removed from this package.

| Legacy name | New name
| --- | ---
| icon-amat-core-branchminus | icon-amat-core-minus-mini
| icon-amat-core-branchplus | icon-amat-core-plus-mini
| icon-amat-core-forward-22 | icon-amat-core-circle-forward
| icon-amat-core-forward-62 | icon-amat-core-fastforward
| icon-amat-core-stop-125 | icon-amat-core-stop
| icon-amat-core-stop-64 | icon-amat-core-stop-square
| icon-amat-core-forward | icon-amat-core-circle-forward
| icon-amat-core-go-down | icon-amat-core-circle-down
| icon-amat-core-go-back | icon-amat-core-circle-back
| icon-amat-core-arrow-collapse | icon-amat-core-up-arrow
| icon-amat-core-arrow-expand | icon-amat-core-down-arrow
| icon-amat-core-plan-details-mini | icon-amat-core-circle-arrow-forward-mini
| icon-amat-core-forward-arrow-mini | icon-amat-core-circle-arrow-forward-mini
| icon-amat-core-check-mini | icon-amat-core-circle-check-mini
| icon-amat-core-warning-critical | icon-amat-core-stop-hand
