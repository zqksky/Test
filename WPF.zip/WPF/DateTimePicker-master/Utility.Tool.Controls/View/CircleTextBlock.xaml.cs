﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Utility.Tool.Controls.View
{
    /// <summary>
    /// Interaction logic for CircleTextBlock.xaml
    /// </summary>
    public partial class CircleTextBlock : UserControl
    {
        public CircleTextBlock()
        {
            InitializeComponent();
        }
        static CircleTextBlock()
        {
            TextProperty = DependencyProperty.Register("Text", typeof(string), typeof(CircleTextBlock));
            FillProperty = DependencyProperty.Register("Fill", typeof(SolidColorBrush), typeof(CircleTextBlock), new PropertyMetadata(new SolidColorBrush(Colors.White)));
            SizeProperty = DependencyProperty.Register("Size", typeof(double), typeof(CircleTextBlock), new FrameworkPropertyMetadata(new Double?(20.0), new PropertyChangedCallback(OnSizeChanged)));
            TextSizeProperty = DependencyProperty.Register("TextSize", typeof(double), typeof(CircleTextBlock));
        }
        private static void OnSizeChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            CircleTextBlock ctb = (CircleTextBlock)sender;
            double size = ctb.Size;
            //以下是根据圆形直径估算的比较合适的文字大小。圆形直径在20以上时，感觉对单个数字的大小还是比较合适的
            if (size > 20)
                ctb.TextSize = size - 8;
            else if (size > 10)
                ctb.TextSize = size - 6;
            else ctb.TextSize = 5;
        }

        /// <summary>
        /// Size should be equal or greater to 20
        /// </summary>
        public double Size
        {
            get
            {
                return (double)GetValue(SizeProperty);
            }
            set
            {
                SetValue(SizeProperty, value);
            }
        }
        private double TextSize
        {
            get
            {
                return (double)GetValue(TextSizeProperty);
            }
            set
            {
                SetValue(TextSizeProperty, value);
            }
        }
        public SolidColorBrush Fill
        {
            get
            {
                return (SolidColorBrush)GetValue(FillProperty);
            }
            set
            {
                SetValue(FillProperty, value);
            }
        }
        public string Text
        {
            get
            {
                return (string)GetValue(TextProperty);
            }
            set
            {
                SetValue(TextProperty, value);
            }
        }
        public static DependencyProperty TextProperty;
        public static DependencyProperty FillProperty;
        public static DependencyProperty SizeProperty;
        public static DependencyProperty TextSizeProperty;
    }
}
