﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDemo.Model
{
    public class StudentInfo
    {
        public string Name { get; set; }
        public string Class { get; set; }
        public string Sex { get; set; }
        public int ClassRank { get; set; }
        public int SchoolRank { get; set; }
    }
}
