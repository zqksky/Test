﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace MvvmDataGridCheckBoxSelectAll
{

    public class PersonListViewModel : NotificationObject
    {
        public PersonListViewModel()
        {
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 1, Name = "张三", Score="40"} });
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 2, Name = "李四", Score = "40" } });
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 3, Name = "王五", Score = "40" } });
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 4, Name = "赵六",  Score = "40" } });
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 5, Name = "刘七", Score = "40" } });
            _Persons.Add(new PersonModel() { Person = new Person() { ID = 6, Name = "陈八",  Score = "40" } });
        }

        private ObservableCollection<PersonModel> _Persons = new ObservableCollection<PersonModel>();
        public ObservableCollection<PersonModel> Persons
        {
            get
            {
                return _Persons;
            }
            set
            {
                _Persons = value;
                this.RaisePropertyChanged("Persons");
            }
        }


        private bool _IsSelectAll = false;
        public bool IsSelectAll
        {
            get { return _IsSelectAll; }
            set
            {
                _IsSelectAll = value;
                RaisePropertyChanged("IsSelectAll");
            }
        }


        private ICommand _SelectAllCommand;
        public ICommand SelectAllCommand
        {
            get
            {
                return _SelectAllCommand ?? (_SelectAllCommand = new DelegateCommand<object>(SelectAll));
            }
        }

        public void SelectAll(object id)
        {
            foreach (var item in Persons)
            {
                item.IsSelected = IsSelectAll;
            }
        }

        private ICommand _SelectCommand;
        public ICommand SelectCommand
        {
            get
            {
                return _SelectCommand ?? (_SelectCommand = new DelegateCommand<int>(Select));
            }
        }

        public void Select(int id)
        {
            PersonModel md = Persons.Where(p => p.IsSelected).FirstOrDefault();
            if (md != null)
            {
                if (!md.IsSelected && IsSelectAll)
                {
                    IsSelectAll = false;
                }
                else if (md.IsSelected && !IsSelectAll)
                {
                    foreach (var item in Persons)
                    {
                        if (!item.IsSelected) return;
                    }
                    IsSelectAll = true;
                }
            }
        }

        public bool SelectValidate(bool onlyOne = false)
        {
            if (this.Persons.Count(p => p.IsSelected) < 1)
            {
                MessageBox.Show("未勾选数据！");
                return false;
            }

            if (onlyOne)
            {
                if (this.Persons.Count(p => p.IsSelected) > 1)
                {
                    MessageBox.Show("只能勾选一条数据！");
                    return false;
                }
            }

            return true;
        }

        private ICommand _DelCommand;
        public ICommand DelCommand
        {
            get
            {
                return _DelCommand ?? (_DelCommand = new DelegateCommand<object>(Del));
            }
        }

        public void Del(object obj = null)
        {
            if (!SelectValidate()) return;

            MessageBoxResult result = MessageBox.Show("是否删除选中项?", "提示", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            StringBuilder sb = new StringBuilder();

            bool hasSelect = false;
            //获取选中的数据
            foreach (var v in _Persons)
            {
                if (v.IsSelected) { sb.Append(v.Person.Name + ";"); hasSelect = true; }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("选中 " + sb.ToString());
        }

        private ICommand _EditCommand;
        public ICommand EditCommand
        {
            get
            {
                return _EditCommand ?? (_EditCommand = new DelegateCommand<object>(Edit));
            }
        }

        public void Edit(object obj = null)
        {
            if (!SelectValidate(true)) return;

            PersonModel model = null;


            bool hasSelect = false;
            //获取选中的数据
            foreach (var v in _Persons)
            {
                if (v.IsSelected) { model = v; hasSelect = true; break; }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("选中 " + model.Person.Name);

        }
    }
}
