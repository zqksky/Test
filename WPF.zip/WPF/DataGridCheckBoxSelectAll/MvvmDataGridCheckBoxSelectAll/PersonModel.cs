﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvvmDataGridCheckBoxSelectAll
{
    public class PersonModel : NotificationObject
    {
        private bool _IsSelected = false;
        public bool IsSelected
        {
            get
            {
                return _IsSelected;
            }
            set
            {
                _IsSelected = value;
                this.RaisePropertyChanged("IsSelected");
            }
        }

        private List<string> _SexList = new List<string>() { "Man","Women"};
        public List<string> SexList
        {
            get
            {
                return _SexList;
            }
            set
            {
                _SexList = value;
                this.RaisePropertyChanged("IsSelected");
            }
        }

        private Person _Person;
        public Person Person
        {
            get
            {
                return _Person;
            }
            set
            {
                _Person = value;
                this.RaisePropertyChanged("Person");
            }
        }
    }
}
