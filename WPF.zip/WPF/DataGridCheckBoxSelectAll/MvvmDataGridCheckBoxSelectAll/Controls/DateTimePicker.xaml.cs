﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Drawing;

namespace MvvmDataGridCheckBoxSelectAll.Controls
{
    /// <summary>
    /// Interaction logic for DateTimePicker.xaml
    /// </summary>
    [ToolboxBitmap(typeof(DateTimePicker), "DateTimePicker.bmp")]  
    public partial class DateTimePicker : UserControl
    {
        [DateTimeDependencyPropertyAttribute]
        public static readonly DependencyProperty DateTimeProperty;

        private string _dateTime;
        public DateTimePicker()
        {
            InitializeComponent();
        }

        #region Action交互

        /// <summary>
        /// 时间确定后的传递事件
        /// </summary>
        public Action<string> DateTimeString;

        /// <summary>
        /// 时间确定后传递的时间内容
        /// </summary>
        /// <param name="dateTimeStr"></param>
        protected void OnDateTimeContent(string dateTimeStr)
        {
            if (DateTimeString != null)
                DateTimeString(_dateTime);
        }

        #endregion
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="txt"></param>
        public DateTimePicker(string txt) : this()
        {
            // this.textBox1.Text = txt;
        }
        public string GetDateTime()
        {
            return textBlock1.Text;
        }
        #region 事件

        /// <summary>
        /// 日历图标点击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void iconButton1_Click(object sender, RoutedEventArgs e)
        {
            if (popChioce.IsOpen == true)
            {
                popChioce.IsOpen = false;
                return;
            }

            TDateTimeView dtView = new TDateTimeView(textBlock1.Text);// TDateTimeView  构造函数传入日期时间

            dtView.DateTimeOK += (dateTimeStr) => //TDateTimeView 日期时间确定事件
            {
                dateTimeStr.Insert(4, "/");
                dateTimeStr.Insert(7, "/");
                textBlock1.Text = dateTimeStr;
                DateTimeTextBox = dateTimeStr;
                DateTime = DateTime.ParseExact(dateTimeStr, "yyyy/MM/dd HH:mm:ss", System.Globalization.CultureInfo.CurrentCulture);
                //DateTime = Convert.ToDateTime(dateTimeStr);
                popChioce.IsOpen = false;//TDateTimeView 所在pop  关闭
                _dateTime = GetDateTime();
            };

            popChioce.Child = dtView;
            popChioce.IsOpen = true;
        }

        /// <summary>
        /// DateTimePicker 窗体登录事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        //private void UserControl_Loaded(object sender, RoutedEventArgs e)
        //{
        //    DateTime dt = DateTime.Now;
        //    textBlock1.Text = dt.ToString("yyyyMMdd HH:mm:ss");//"yyyyMMddHHmmss"
        //    DateTime = dt;            
        //  //  DateTime = Convert.ToDateTime(textBlock1.Text);
        //}


        #endregion

        #region 属性

        /// <summary>
        /// 日期时间
        /// </summary>
        public DateTime DateTime
        {
            get; set;
        }

        #endregion


        public string DateTimeTextBox
        {
            get { return (string)GetValue(DateTimeTextBoxProperty); }
            set
            {
                SetValue(DateTimeTextBoxProperty, value);
                if (value != null)
                    textBlock1.Text = value;
            }
        }

        // Using a DependencyProperty as the backing store for VisibilityShowAllCheckBox.  This enables animation, styling, binding, etc...
        public static DependencyProperty DateTimeTextBoxProperty =
            DependencyProperty.Register("DateTimeTextBox", typeof(string), typeof(DateTimePicker), new PropertyMetadata(OnButtonVisibilityChanged));


        private static void OnButtonVisibilityChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var dateTimePicker = d as DateTimePicker;
            if (e.Property == DateTimeTextBoxProperty)
            {
                dateTimePicker.textBlock1.Text = (string)e.NewValue;
            }
            else { }
        }
    }
}