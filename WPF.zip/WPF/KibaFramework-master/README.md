# KibaFramework
这是一款基于WPF的MVVM框架，主要用于合理的处理业务。 
# 框架介绍系列文章。
《【我们一起写框架】MVVM的WPF框架（一）—序篇》https://www.cnblogs.com/kiba/p/9565299.html  
《【我们一起写框架】MVVM的WPF框架（二）—绑定》https://www.cnblogs.com/kiba/p/9610364.html   
《【我们一起写框架】MVVM的WPF框架（三）—数据控件》https://www.cnblogs.com/kiba/p/9648808.html   
《【我们一起写框架】MVVM的WPF框架（四）—DataGrid》https://www.cnblogs.com/kiba/p/9753893.html   
《【我们一起写框架】MVVM的WPF框架（五）—完结篇》https://www.cnblogs.com/kiba/p/9860135.html  
