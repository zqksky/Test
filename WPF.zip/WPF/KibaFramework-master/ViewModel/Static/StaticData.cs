﻿using DTO;
using Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using Utility;
 

namespace ViewModel.Static
{
    public static class StaticData
    {  
        public static List<DataGridConfig> DataGridConfig = new List<DataGridConfig>();
    }
}
